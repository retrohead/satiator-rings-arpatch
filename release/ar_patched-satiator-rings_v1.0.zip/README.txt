----------------------------
SATIATOR RINGS AR PATCH V1.0
----------------------------

Installation:

1. Flash the included patched AR firmware to your AR device using the official Satiator Menu.
2. Place the boot.desc file on the root of your SD card.
3. Ensure satiator-rings.iso is on the root of your SD card.
4. Enjoy :)


--------
CREDITS
--------

Professor Abraisive for the Satiator and original AR patch code.
DreamscapeLuke for his assistance with compiling the code in a Linux environment.


-----
INFO
-----

Visit me on the Satiator Discord if you have any questions.